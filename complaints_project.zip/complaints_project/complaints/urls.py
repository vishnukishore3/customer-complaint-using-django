from django.urls import path
from . import views

urlpatterns = [
    path('', views.submit_complaint, name='submit_complaint'),
    path('success/', views.success_page, name='success'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
]
